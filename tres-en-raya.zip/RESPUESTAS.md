# Respuestas · Parte 2

Nombre y apellidos: Imanol Margarit Lopis

## 1. ¿Cómo sabe el programa si toca colocar o mover? ¿Has usado un estado o un valor calculado? ¿Por qué?
con la funcion de faseMover mira si un jugador tiene todas las fichas en el tablero.
## 2. ¿Dónde guardas la ficha seleccionada? ¿Por qué no forma parte del historial?

## 3. ¿Cómo mueves una ficha sin modificar el tablero original?

## 4. ¿Sigue funcionando el cálculo de xIsNext a partir de currentMove? Justifícalo
